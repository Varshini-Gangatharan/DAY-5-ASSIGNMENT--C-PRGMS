/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LENGTH 1024
int main() 
{
    FILE *input_file, *output_file;
    char line[MAX_LENGTH];
    char *word, *rest;
    char new_line[MAX_LENGTH];
    input_file = fopen("input.txt", "r");
    if (input_file == NULL) 
    {
        printf("Error opening input file\n");
        exit(1);
    }
    output_file = fopen("output.txt", "w");
    if (output_file == NULL) 
    {
        printf("Error opening output file\n");
        exit(1);
    }
    while (fgets(line, MAX_LENGTH, input_file)) 
    {
        rest = line;
        while ((word = strtok_r(rest, " \t\n", &rest))) 
        {
            if (strcmp(word, "red") == 0) 
            {
                strcat(new_line, "blue");
            } else 
            {
                strcat(new_line, word);
            }
            strcat(new_line, " ");
        }
        fputs(new_line, output_file);
        strcpy(new_line, "");
    }
    fclose(input_file);
    fclose(output_file);
    return 0;
}


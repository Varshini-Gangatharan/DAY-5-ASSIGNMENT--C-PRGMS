#include <stdio.h>
#include <string.h>
#define BUFFER_SIZE 1024
int main() 
{
    FILE *input_file = fopen("input.txt", "r");
    FILE *error_file = fopen("error_log.txt", "w");
    if (input_file == NULL || error_file == NULL) {
        printf("Error opening files.\n");
        return 1;
    }
    char buffer[BUFFER_SIZE];
    while (fgets(buffer, BUFFER_SIZE, input_file)) 
    {
        if (strstr(buffer, "error")) 
        {
            fputs(buffer, error_file);
        }
    }
    fclose(input_file);
    fclose(error_file);
    error_file = fopen("error_log.txt", "r");
    if (error_file == NULL) {
        printf("Error opening error_log.txt.\n");
        return 1;
    }
    printf("Contents of error_log.txt:\n");
    while (fgets(buffer, BUFFER_SIZE, error_file)) 
    {
        printf("%s", buffer);
    }
    fclose(error_file);
    return 0;
}

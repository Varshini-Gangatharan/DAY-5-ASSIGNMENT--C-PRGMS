/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LENGTH 1024
int main() 
{
    char filename[MAX_LENGTH], search_string[MAX_LENGTH], line[MAX_LENGTH];
    FILE *fp;
    printf("Enter the name of the file: ");
    fgets(filename, MAX_LENGTH, stdin);
    filename[strcspn(filename, "\n")] = 0;
    printf("Enter a search string: ");
    fgets(search_string, MAX_LENGTH, stdin);
    search_string[strcspn(search_string, "\n")] = 0;
    fp = fopen(filename, "r");
    if (fp == NULL) 
    {
        printf("Error opening file\n");
        exit(1);
    }
    while (fgets(line, MAX_LENGTH, fp)) 
    {
        if (strstr(line, search_string) != NULL) 
        {
            printf("%s", line);
        }
    }
    fclose(fp);
    return 0;
}


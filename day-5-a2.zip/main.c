/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int main() {
    FILE *fp;
    int buffer[1024];
    int num_elements;
    fp = fopen("data.bin", "rb");
    if (fp == NULL) {
        printf("Error opening file\n");
        exit(1);
    }
    num_elements = fread(buffer, sizeof(int), 1024, fp);
    printf("Data from file:\n");
    for (int i = 0; i < num_elements; i++) {
        printf("%d ", buffer[i]);
    }
    printf("\n");
    fclose(fp);
    return 0;
}

